import React from 'react';

const WorkoutContext = React.createContext({});

export default WorkoutContext;
